import React from 'react'
import '../../App.css'
export default function Marketing() {

    return (
        <>
            <h1 className='consulting'>Marketing</h1>
        </>
    )
}