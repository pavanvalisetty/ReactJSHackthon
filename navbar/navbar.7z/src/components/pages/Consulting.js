import React from 'react'
import '../../App.css'

export default function Consulting() {

    return (
        <>
            <h1 className='consulting'>Consulting</h1>
        </>
    )
}