import React from 'react'
import '../../App.css'
import DisplayTable from './DisplayTable'

export default function Home() {

    return (
        <>
            <h1 className='consulting'>EPIC</h1>
            <DisplayTable />
        </>
    )
}